package org.demo.business;

import javax.ejb.Local;

@Local
public interface ServiceRequestSessionLocal {
  void sendMailMessage(String from, String to, String subject,  String content);
}
