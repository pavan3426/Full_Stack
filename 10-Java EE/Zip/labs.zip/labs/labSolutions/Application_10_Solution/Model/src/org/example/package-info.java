@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.example.org", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package org.example;
