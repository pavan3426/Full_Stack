package training.iqgateway.entities;

import java.io.Serializable;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@NamedQueries({
  @NamedQuery(name = "OffenceDetailsEO.findAll", query = "select o from OffenceDetailsEO o")
})
@Table(name = "TM_OFFENCE_DETAILS")
public class OffenceDetailsEO implements Serializable {
    private byte[] image;
    @Id
    @Column(name="OFFENCE_DETAIL_ID", nullable = false)
    private Long offenceDetailId;
    @Column(name="OFFENCE_STATUS", length = 20)
    private String offenceStatus;
    @Column(nullable = false, length = 200)
    private String place;
    @Column(nullable = false)
    private Timestamp time;
    @ManyToOne
    @JoinColumn(name = "REPORTED_BY")
    private UserEO userEO;
    @ManyToOne
    @JoinColumn(name = "OFFENCE_ID")
    private OffenceEO offenceEO;
    @ManyToOne
    @JoinColumn(name = "VEH_NO")
    private RegistrationEO registrationEO;

    public OffenceDetailsEO() {
    }

    public OffenceDetailsEO(Long offenceDetailId, OffenceEO offenceEO,
                            String offenceStatus, String place, UserEO userEO, Timestamp time, RegistrationEO registrationEO) {
        this.offenceDetailId = offenceDetailId;
        this.offenceEO = offenceEO;
        this.offenceStatus = offenceStatus;
        this.place = place;
        this.userEO = userEO;
        this.time = time;
        this.registrationEO = registrationEO;
    }

    public byte[] getImage() {
        return image;
    }

    public void setImage(byte[] image) {
        this.image = image;
    }

    public Long getOffenceDetailId() {
        return offenceDetailId;
    }

    public void setOffenceDetailId(Long offenceDetailId) {
        this.offenceDetailId = offenceDetailId;
    }


    public String getOffenceStatus() {
        return offenceStatus;
    }

    public void setOffenceStatus(String offenceStatus) {
        this.offenceStatus = offenceStatus;
    }

    public String getPlace() {
        return place;
    }

    public void setPlace(String place) {
        this.place = place;
    }


    public Timestamp getTime() {
        return time;
    }

    public void setTime(Timestamp time) {
        this.time = time;
    }


    public UserEO getUserEO() {
        return userEO;
    }

    public void setUserEO(UserEO userEO) {
        this.userEO = userEO;
    }

    public OffenceEO getOffenceEO() {
        return offenceEO;
    }

    public void setOffenceEO(OffenceEO offenceEO) {
        this.offenceEO = offenceEO;
    }

    public RegistrationEO getRegistrationEO() {
        return registrationEO;
    }

    public void setRegistrationEO(RegistrationEO registrationEO) {
        this.registrationEO = registrationEO;
    }
}
