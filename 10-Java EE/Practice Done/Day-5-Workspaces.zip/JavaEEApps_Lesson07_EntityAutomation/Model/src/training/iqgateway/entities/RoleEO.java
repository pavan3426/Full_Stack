package training.iqgateway.entities;

import java.io.Serializable;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@NamedQueries({
  @NamedQuery(name = "RoleEO.findAll", query = "select o from RoleEO o")
})
@Table(name = "TM_ROLEMASTER")
public class RoleEO implements Serializable {
    @Id
    @Column(nullable = false, length = 20)
    private String rolename;
    @Column(name="ROLE_DESC", length = 100)
    private String roleDesc;
    @OneToMany(mappedBy = "roleEO")
    private List<UserEO> userEOList;

    public RoleEO() {
    }

    public RoleEO(String roleDesc, String rolename) {
        this.roleDesc = roleDesc;
        this.rolename = rolename;
    }

    public String getRolename() {
        return rolename;
    }

    public void setRolename(String rolename) {
        this.rolename = rolename;
    }

    public String getRoleDesc() {
        return roleDesc;
    }

    public void setRoleDesc(String roleDesc) {
        this.roleDesc = roleDesc;
    }

    public List<UserEO> getUserEOList() {
        return userEOList;
    }

    public void setUserEOList(List<UserEO> userEOList) {
        this.userEOList = userEOList;
    }

    public UserEO addUserEO(UserEO userEO) {
        getUserEOList().add(userEO);
        userEO.setRoleEO(this);
        return userEO;
    }

    public UserEO removeUserEO(UserEO userEO) {
        getUserEOList().remove(userEO);
        userEO.setRoleEO(null);
        return userEO;
    }
}
