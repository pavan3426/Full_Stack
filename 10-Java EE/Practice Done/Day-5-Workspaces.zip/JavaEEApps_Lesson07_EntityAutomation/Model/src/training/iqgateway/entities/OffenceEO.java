package training.iqgateway.entities;

import java.io.Serializable;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@NamedQueries({
  @NamedQuery(name = "OffenceEO.findAll", query = "select o from OffenceEO o")
})
@Table(name = "TM_OFFENCE")
public class OffenceEO implements Serializable {
    @Id
    @Column(name="OFFENCE_ID", nullable = false)
    private Long offenceId;
    @Column(name="OFFENCE_TYPE", nullable = false, length = 200)
    private String offenceType;
    @Column(nullable = false)
    private Long penalty;
    @Column(name="VEH_TYPE", nullable = false, length = 50)
    private String vehType;
    @OneToMany(mappedBy = "offenceEO")
    private List<OffenceDetailsEO> offenceDetailsEOList;

    public OffenceEO() {
    }

    public OffenceEO(Long offenceId, String offenceType, Long penalty,
                     String vehType) {
        this.offenceId = offenceId;
        this.offenceType = offenceType;
        this.penalty = penalty;
        this.vehType = vehType;
    }

    public Long getOffenceId() {
        return offenceId;
    }

    public void setOffenceId(Long offenceId) {
        this.offenceId = offenceId;
    }

    public String getOffenceType() {
        return offenceType;
    }

    public void setOffenceType(String offenceType) {
        this.offenceType = offenceType;
    }

    public Long getPenalty() {
        return penalty;
    }

    public void setPenalty(Long penalty) {
        this.penalty = penalty;
    }

    public String getVehType() {
        return vehType;
    }

    public void setVehType(String vehType) {
        this.vehType = vehType;
    }

    public List<OffenceDetailsEO> getOffenceDetailsEOList() {
        return offenceDetailsEOList;
    }

    public void setOffenceDetailsEOList(List<OffenceDetailsEO> offenceDetailsEOList) {
        this.offenceDetailsEOList = offenceDetailsEOList;
    }

    public OffenceDetailsEO addOffenceDetailsEO(OffenceDetailsEO offenceDetailsEO) {
        getOffenceDetailsEOList().add(offenceDetailsEO);
        offenceDetailsEO.setOffenceEO(this);
        return offenceDetailsEO;
    }

    public OffenceDetailsEO removeOffenceDetailsEO(OffenceDetailsEO offenceDetailsEO) {
        getOffenceDetailsEOList().remove(offenceDetailsEO);
        offenceDetailsEO.setOffenceEO(null);
        return offenceDetailsEO;
    }
}
