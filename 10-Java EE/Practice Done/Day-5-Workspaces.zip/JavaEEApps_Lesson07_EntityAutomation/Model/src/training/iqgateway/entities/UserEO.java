package training.iqgateway.entities;

import java.io.Serializable;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@NamedQueries({
  @NamedQuery(name = "UserEO.findAll", query = "select o from UserEO o")
})
@Table(name = "TM_USERMASTER")
public class UserEO implements Serializable {
    @Column(nullable = false, length = 20)
    private String password;
    @Id
    @Column(nullable = false, length = 20)
    private String username;
    @ManyToOne
    @JoinColumn(name = "ROLENAME")
    private RoleEO roleEO;
    @OneToMany(mappedBy = "userEO")
    private List<OffenceDetailsEO> offenceDetailsEOList;

    public UserEO() {
    }

    public UserEO(String password, RoleEO roleEO, String username) {
        this.password = password;
        this.roleEO = roleEO;
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }


    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public RoleEO getRoleEO() {
        return roleEO;
    }

    public void setRoleEO(RoleEO roleEO) {
        this.roleEO = roleEO;
    }

    public List<OffenceDetailsEO> getOffenceDetailsEOList() {
        return offenceDetailsEOList;
    }

    public void setOffenceDetailsEOList(List<OffenceDetailsEO> offenceDetailsEOList) {
        this.offenceDetailsEOList = offenceDetailsEOList;
    }

    public OffenceDetailsEO addOffenceDetailsEO(OffenceDetailsEO offenceDetailsEO) {
        getOffenceDetailsEOList().add(offenceDetailsEO);
        offenceDetailsEO.setUserEO(this);
        return offenceDetailsEO;
    }

    public OffenceDetailsEO removeOffenceDetailsEO(OffenceDetailsEO offenceDetailsEO) {
        getOffenceDetailsEOList().remove(offenceDetailsEO);
        offenceDetailsEO.setUserEO(null);
        return offenceDetailsEO;
    }
}
