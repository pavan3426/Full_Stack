package training.iqgateway.entities;

import java.io.Serializable;

import java.sql.Timestamp;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@NamedQueries({
  @NamedQuery(name = "RegistrationEO.findAll", query = "select o from RegistrationEO o")
})
@Table(name = "TM_REGDETAILS")
public class RegistrationEO implements Serializable {
    @Column(name="APP_NO", nullable = false)
    private Long appNo;
    @Column(name="DATE_OF_PURCHASE", nullable = false)
    private Timestamp dateOfPurchase;
    @Column(name="DISTRUBUTER_NAME", nullable = false, length = 200)
    private String distrubuterName;
    @Id
    @Column(name="VEH_NO", nullable = false, length = 20)
    private String vehNo;
    @ManyToOne
    @JoinColumn(name = "OWNER_ID")
    private OwnerEO ownerEO;
    @ManyToOne
    @JoinColumn(name = "VEH_ID")
    private VehicleEO vehicleEO;
    @OneToMany(mappedBy = "registrationEO")
    private List<OffenceDetailsEO> offenceDetailsEOList;

    public RegistrationEO() {
    }

    public RegistrationEO(Long appNo, Timestamp dateOfPurchase,
                          String distrubuterName, OwnerEO ownerEO,
                          VehicleEO vehicleEO,
                          String vehNo) {
        this.appNo = appNo;
        this.dateOfPurchase = dateOfPurchase;
        this.distrubuterName = distrubuterName;
        this.ownerEO = ownerEO;
        this.vehicleEO = vehicleEO;
        this.vehNo = vehNo;
    }

    public Long getAppNo() {
        return appNo;
    }

    public void setAppNo(Long appNo) {
        this.appNo = appNo;
    }

    public Timestamp getDateOfPurchase() {
        return dateOfPurchase;
    }

    public void setDateOfPurchase(Timestamp dateOfPurchase) {
        this.dateOfPurchase = dateOfPurchase;
    }

    public String getDistrubuterName() {
        return distrubuterName;
    }

    public void setDistrubuterName(String distrubuterName) {
        this.distrubuterName = distrubuterName;
    }


    public String getVehNo() {
        return vehNo;
    }

    public void setVehNo(String vehNo) {
        this.vehNo = vehNo;
    }

    public OwnerEO getOwnerEO() {
        return ownerEO;
    }

    public void setOwnerEO(OwnerEO ownerEO) {
        this.ownerEO = ownerEO;
    }

    public VehicleEO getVehicleEO() {
        return vehicleEO;
    }

    public void setVehicleEO(VehicleEO vehicleEO) {
        this.vehicleEO = vehicleEO;
    }

    public List<OffenceDetailsEO> getOffenceDetailsEOList() {
        return offenceDetailsEOList;
    }

    public void setOffenceDetailsEOList(List<OffenceDetailsEO> offenceDetailsEOList) {
        this.offenceDetailsEOList = offenceDetailsEOList;
    }

    public OffenceDetailsEO addOffenceDetailsEO(OffenceDetailsEO offenceDetailsEO) {
        getOffenceDetailsEOList().add(offenceDetailsEO);
        offenceDetailsEO.setRegistrationEO(this);
        return offenceDetailsEO;
    }

    public OffenceDetailsEO removeOffenceDetailsEO(OffenceDetailsEO offenceDetailsEO) {
        getOffenceDetailsEOList().remove(offenceDetailsEO);
        offenceDetailsEO.setRegistrationEO(null);
        return offenceDetailsEO;
    }
}
