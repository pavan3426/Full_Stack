package training.iqgateway;

import javax.ejb.Local;

@Local
public interface CurrencyConverterLocal {
    
    public double dollarToRS(double dollars);
    
    public double poundsToRS(double pounds);
    
    public double eurosToRS(double euros);
    
    public double riyalsToRS(double riyals);
    
    public double yensToRS(double yens);
    
    public double pesosToRS(double pesos);
      
}
