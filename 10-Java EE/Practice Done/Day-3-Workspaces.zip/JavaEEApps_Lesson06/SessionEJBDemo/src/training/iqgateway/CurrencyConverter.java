package training.iqgateway;

import javax.ejb.Remote;

@Remote
public interface CurrencyConverter {
    
    public double dollarToRS(double dollars);
    
    public double poundsToRS(double pounds);
    
    public double eurosToRS(double euros);
    
    public double riyalsToRS(double riyals);
    
  
}
