package training.iqgateway.model;

import javax.ejb.Remote;

@Remote
public interface OurCurrencyConvertor {
    
    public double dollarToRS(double dollars);
    
}
