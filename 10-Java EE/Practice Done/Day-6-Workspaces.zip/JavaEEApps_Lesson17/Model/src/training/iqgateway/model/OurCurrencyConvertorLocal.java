package training.iqgateway.model;

import javax.ejb.Local;

@Local
public interface OurCurrencyConvertorLocal {
}
