package training.iqgateway.model;

import javax.ejb.Stateless;

@Stateless(name = "OurCurrencyConvertor", mappedName = "JavaEEApps_Lesson17-Model-OurCurrencyConvertor")
public class OurCurrencyConvertorBean implements OurCurrencyConvertor,
                                                 OurCurrencyConvertorLocal {
    public OurCurrencyConvertorBean() {
    }

    public double dollarToRS(double dollars) {
        return 69.23 * dollars;
    }
}
