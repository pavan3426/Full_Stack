package training.iqgateway;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.*;
import javax.servlet.http.*;

public class LoginServlet extends HttpServlet {
    private static final String CONTENT_TYPE = "text/html; charset=windows-1252";

    public void init(ServletConfig config) throws ServletException {
        super.init(config);
    }

    public void doPost(HttpServletRequest request,
                      HttpServletResponse response) throws ServletException,
                                                           IOException {
        response.setContentType(CONTENT_TYPE);
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<head><title>LoginServlet</title></head>");
        out.println("<body>");
        
        String givenUsername1 = request.getParameter("username1");
        String givenPassword1 = request.getParameter("password1");
        
        String givenUsername2 = request.getParameter("username2");
        String givenPassword2 = request.getParameter("password2");
        
        // Invoke Business Operations 
        
        out.println("<h3> Welcome, " + givenUsername1 + givenUsername2 + " to the New World of Web Apps" + "</h3>");
        out.println("</body></html>");
        out.close();
    }
}
