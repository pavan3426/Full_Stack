package training.iqgateway;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.*;
import javax.servlet.http.*;

public class DateTimeServlet extends HttpServlet {
    
    private static final String CONTENT_TYPE = "text/html; charset=windows-1252";

    public void init(ServletConfig config) throws ServletException {
        super.init(config);
    }

    public void doGet(HttpServletRequest request,
                      HttpServletResponse response) throws ServletException,
                                                           IOException {
        response.setContentType(CONTENT_TYPE);
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<head><title>DateTimeServlet</title></head>");
        out.println("<body bgcolor=\"pink\">");
        java.util.Date dobj = new java.util.Date();
        out.println("<h2> The Current Date and Time on Server is : " + dobj + " </h2>");
        out.println("</body></html>");
        out.close();
    }
}
