-- $Id: CUSTOMER_INTERESTS.sql 888 2007-03-01 16:27:31Z drmills $
REM insert into CUSTOMER_INTERESTS VALUES (
REM    CUSTOMER_ID,
REM    CUSTOMER_INTERESTS_ID,
REM    CATEGORY_ID,
REM    CREATED_BY,
REM    CREATION_DATE,
REM    LAST_UPDATED_BY,
REM    LAST_UPDATE_DATE,
REM    OBJECT_VERSION_ID
REM );

insert into CUSTOMER_INTERESTS VALUES (
    110,
    1,
    4,
    0,
    SYSDATE,
    0,
    SYSDATE,
    0
);

insert into CUSTOMER_INTERESTS VALUES (
    111,
    2,
    1,
    0,
    SYSDATE,
    0,
    SYSDATE,
    0
);

insert into CUSTOMER_INTERESTS VALUES (
    112,
    3,
    8,
    0,
    SYSDATE,
    0,
    SYSDATE,
    0
);

insert into CUSTOMER_INTERESTS VALUES (
    113,
    4,
    14,
    0,
    SYSDATE,
    0,
    SYSDATE,
    0
);

insert into CUSTOMER_INTERESTS VALUES (
    114,
    5,
    5,
    0,
    SYSDATE,
    0,
    SYSDATE,
    0
);

insert into CUSTOMER_INTERESTS VALUES (
    115,
    6,
    7,
    0,
    SYSDATE,
    0,
    SYSDATE,
    0
);

insert into CUSTOMER_INTERESTS VALUES (
    116,
    7,
    3,
    0,
    SYSDATE,
    0,
    SYSDATE,
    0
);

insert into CUSTOMER_INTERESTS VALUES (
    117,
    8,
    6,
    0,
    SYSDATE,
    0,
    SYSDATE,
    0
);

insert into CUSTOMER_INTERESTS VALUES (
    118,
    9,
    10,
    0,
    SYSDATE,
    0,
    SYSDATE,
    0
);

insert into CUSTOMER_INTERESTS VALUES (
    119,
    10,
    13,
    0,
    SYSDATE,
    0,
    SYSDATE,
    0
);

insert into CUSTOMER_INTERESTS VALUES (
    120,
    11,
    9,
    0,
    SYSDATE,
    0,
    SYSDATE,
    0
);

insert into CUSTOMER_INTERESTS VALUES (
    121,
    12,
    11,
    0,
    SYSDATE,
    0,
    SYSDATE,
    0
);

insert into CUSTOMER_INTERESTS VALUES (
    122,
    13,
    9,
    0,
    SYSDATE,
    0,
    SYSDATE,
    0
);

insert into CUSTOMER_INTERESTS VALUES (
    123,
    14,
    11,
    0,
    SYSDATE,
    0,
    SYSDATE,
    0
);

insert into CUSTOMER_INTERESTS VALUES (
    124,
    15,
    13,
    0,
    SYSDATE,
    0,
    SYSDATE,
    0
);

insert into CUSTOMER_INTERESTS VALUES (
    125,
    16,
    14,
    0,
    SYSDATE,
    0,
    SYSDATE,
    0
);