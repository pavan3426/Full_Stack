REM Define the discount options for partners in the system
REM $Id: ELIGIBLE_DISCOUNTS.sql 888 2007-03-01 16:27:31Z drmills $

insert into ELIGIBLE_DISCOUNTS values (1, 3, sysdate, add_months(sysdate,+6), 0, SYSDATE,0,SYSDATE,0);
insert into ELIGIBLE_DISCOUNTS values (2, 5, sysdate, add_months(sysdate,+18), 0, SYSDATE,0,SYSDATE,0);
insert into ELIGIBLE_DISCOUNTS values (3, 6, sysdate, add_months(sysdate,+30), 0, SYSDATE,0,SYSDATE,0);
insert into ELIGIBLE_DISCOUNTS values (4, 7, sysdate, add_months(sysdate,+25), 0, SYSDATE,0,SYSDATE,0);
insert into ELIGIBLE_DISCOUNTS values (5, 3, sysdate, add_months(sysdate,+6), 0, SYSDATE,0,SYSDATE,0);
insert into ELIGIBLE_DISCOUNTS values (6, 6, sysdate, add_months(sysdate,+30), 0, SYSDATE,0,SYSDATE,0);
insert into ELIGIBLE_DISCOUNTS values (7, 5, sysdate, add_months(sysdate,+18), 0, SYSDATE,0,SYSDATE,0);
insert into ELIGIBLE_DISCOUNTS values (8, 5, sysdate, add_months(sysdate,+18), 0, SYSDATE,0,SYSDATE,0);
insert into ELIGIBLE_DISCOUNTS values (9, 4, sysdate, add_months(sysdate,+12), 0, SYSDATE,0,SYSDATE,0);
insert into ELIGIBLE_DISCOUNTS values (10, 6, sysdate, add_months(sysdate,+30), 0, SYSDATE,0,SYSDATE,0);
insert into ELIGIBLE_DISCOUNTS values (11, 6, sysdate, add_months(sysdate,+30), 0, SYSDATE,0,SYSDATE,0);
insert into ELIGIBLE_DISCOUNTS values (12, 4, sysdate, add_months(sysdate,+12), 0, SYSDATE,0,SYSDATE,0);
insert into ELIGIBLE_DISCOUNTS values (13, 7, sysdate, add_months(sysdate,+25), 0, SYSDATE,0,SYSDATE,0);
insert into ELIGIBLE_DISCOUNTS values (14, 7, sysdate, add_months(sysdate,+25), 0, SYSDATE,0,SYSDATE,0);