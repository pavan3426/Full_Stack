/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package training.iqgateway.iterator;

/**
 *
 * @author pavankumar.boyapati
 */
public enum ChannelTypeEnum {
 KANNADA,TELUGU, HINDI,ENGLISH, ALL; 
}
