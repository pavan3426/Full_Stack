var celsius = 60;
console.log(celsiusToFahrenheit(celsius)+" F");

function celsiusToFahrenheit( celsius){
    return (celsius*9/5) +32 ;
}
