buf = new Buffer(256);
len = buf.write(" Simple Easy Learning With Node JS");
console.log("Octets Written : " + len);