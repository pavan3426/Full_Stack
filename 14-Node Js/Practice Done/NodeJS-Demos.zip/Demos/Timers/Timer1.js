
setInterval(function(){
    console.log(' Set Interval : Hey! 1 MilliSecond Completed ... ');
}, 5000);