
setTimeout(function(){
    console.log("Set Time Out: Hey! 1 MilliSecond Completed ... ");
},5000);