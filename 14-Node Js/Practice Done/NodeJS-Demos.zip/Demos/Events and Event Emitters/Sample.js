
child_process.exec(command[, options], callback)  