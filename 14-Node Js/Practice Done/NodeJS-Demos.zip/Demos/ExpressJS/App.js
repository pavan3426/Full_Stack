var express = require('express');

var app = express();



var server = app.listen(5000, function(){
    console.log(' Node JS Server is Running ');
})