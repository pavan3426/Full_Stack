var http = require('http');

var server = http.createServer(function(req, res){

    // Handle Your Incoming Request Out Here...

});

server.listen(5000);

console.log(' Node.js Web Server at Port 5000 is Running ... ');