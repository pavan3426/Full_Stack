
console.log(' Welcome to New Era of Developing Applications Using Node ');