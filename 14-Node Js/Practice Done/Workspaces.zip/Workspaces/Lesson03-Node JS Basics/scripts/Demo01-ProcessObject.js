process.execPath
process.pid
process.cwd()