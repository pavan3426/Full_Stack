var myLogModule = require('./Demo03-LocalModuleToExport');

myLogModule.info("Its a Information Message ... ");