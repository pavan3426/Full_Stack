//console.log(new Error('Hello ! This is a Wrong Method ... '));

const name = "Rahul";
console.warn(`Don't Mess with ${name} ! `);