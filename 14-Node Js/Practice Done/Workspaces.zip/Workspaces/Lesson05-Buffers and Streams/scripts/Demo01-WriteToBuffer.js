buf = new Buffer(256);
len = buf.write("Node JS Is Simply Superb ... ");
console.log("Octets Written : " + len);