setTimeout(function(){
    console.log("SetTimeout : Hey 1 MilliSecond Completed ! ... ");
},1000);