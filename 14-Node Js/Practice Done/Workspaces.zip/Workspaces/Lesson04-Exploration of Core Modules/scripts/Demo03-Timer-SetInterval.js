setInterval(function(){
    console.log("SetInterval: Hey 1 MilliSecond Completed ! ... ");
},1000);