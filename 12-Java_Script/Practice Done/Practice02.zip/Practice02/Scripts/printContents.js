function contents()
{
    window.print();
}

contents();