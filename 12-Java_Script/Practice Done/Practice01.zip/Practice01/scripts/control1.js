function larger(a,b){
    return a>b?a:b;
 }
 
 
 var a=9;
 var b=8;
 console.log("larger is" +larger(a,b));