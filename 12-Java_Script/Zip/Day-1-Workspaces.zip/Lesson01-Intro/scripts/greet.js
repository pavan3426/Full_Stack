var givenName = document.getElementById("nameSpan");
givenName.innerHTML = "Rahul Dravid";