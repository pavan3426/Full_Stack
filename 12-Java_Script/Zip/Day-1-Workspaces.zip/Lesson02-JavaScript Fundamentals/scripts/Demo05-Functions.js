function multiply(x, y) {
    var result = x * y;
    return result;
}

var total = multiply(135, 6);
console.log("Result is : " + total);