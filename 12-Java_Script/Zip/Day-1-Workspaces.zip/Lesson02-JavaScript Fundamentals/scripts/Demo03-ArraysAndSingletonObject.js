// Arrays
var courses = ["JavaScript", "TypeScript", "NodeJS" , "React", "Angular", "Vue", "OJET"];
var students= [10, 14, 12, 23, 23, 17, 26];

// Singleton Object
var course = {
    name: "JavaScript Essentials",
    students: 9,
    frequency: "Daily"
};

// Accessing Array Elements 
console.log(courses[0] + "\t" +students[0] + "\t" + courses[3] + "\t" + students[3]);

// Accessing the Object Attributes 
console.log("Course Details ");
console.log(course.name + "\t" + course.students + "\t" + course.frequency);

