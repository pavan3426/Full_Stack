var myObj = {
    print: function() {
        console.log("Hello Everyone ... ");
    }
}

myObj.print();