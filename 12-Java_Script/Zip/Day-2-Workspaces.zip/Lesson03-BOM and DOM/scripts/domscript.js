// var target = document.getElementById("movie-details");
// alert(target.nodeName);

// var artistList = document.getElementsByTagName("li");

// for(var i = 0 ; i < artistList.length; i++) {
//     alert(artistList[i].nodeName + "\t" + artistList[i].textContent);
// }


// Finding the Parent Node
// var vikram = document.getElementById("vikram-2022");
// var sectionElement = vikram.parentNode;
// alert(sectionElement.nodeName);

// Finding the Child Nodes
// var artist = document.getElementById("artist-list");
// var vijaySetupathiElement = artist.childNodes[2];
// alert(vijaySetupathiElement);

// Reading Attribute Values
var anchorElement = document.getElementById("vikram-2022");
alert(anchorElement.getAttribute("href"));
