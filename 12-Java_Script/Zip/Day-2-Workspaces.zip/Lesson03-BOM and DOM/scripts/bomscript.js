function showDetails(){
    // window.alert("Hello From Window Object ... ");

    // alert(window.closed);

    // window.status = "Welcome to BOM in the Status Bar";

    // window.alert(window.outerWidth + "\t" + window.outerHeight);

    // window.open("https://www.google.com");

    // window.prompt("Enter Your Age : ");

    // window.confirm();


    // Location Object Details
    // alert(window.location.host);
    // alert(window.location.hostname);
    // alert(window.location.href);


    // Screen Object Details
    // alert(screen.height + "\t" + screen.width);
    // alert(screen.colorDepth);

    document.write(" Welcome to DOM ... ");
    
    document.writeln("Content in Another Line ... ");

    document.write("Another Statement ");

}