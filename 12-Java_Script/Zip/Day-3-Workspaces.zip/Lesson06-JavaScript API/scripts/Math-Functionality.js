//var mathRef = new Math();

// Common Properties Which we use
console.log(Math.E + "\t" + Math.PI);

// Math Operations Which We Generally Use
console.log(Math.sqrt(729));