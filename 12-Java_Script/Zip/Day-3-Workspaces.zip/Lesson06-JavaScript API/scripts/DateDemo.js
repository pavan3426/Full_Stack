var sysDate = new Date();

console.log(sysDate);

var nowDate = new Date("2023-05-12T21:10:00");

console.log(nowDate.getDate());
