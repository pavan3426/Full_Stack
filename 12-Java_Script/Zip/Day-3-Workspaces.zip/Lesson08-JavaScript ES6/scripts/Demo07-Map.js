var studentsScoreMap = new Map();
    studentsScoreMap.set('Steven' , 90);
    studentsScoreMap.set('Ed', 96);
    studentsScoreMap.set('Rahul', 91);
    studentsScoreMap.set('Nancy', 88);
    studentsScoreMap.set('Danny' , 78);
    studentsScoreMap.set('Larry' , 96);
    studentsScoreMap.set('Steven', 80);

console.log(studentsScoreMap.size);