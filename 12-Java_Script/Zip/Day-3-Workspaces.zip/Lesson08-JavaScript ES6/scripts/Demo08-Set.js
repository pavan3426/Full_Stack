var setObjRef = new Set(['Rahul', 'Ramesh', 'Nancy', 'Steven', 'Rahul']);

console.log(setObjRef.size);

console.log(setObjRef);