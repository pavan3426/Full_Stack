let colors = ['Red', 'Green', 'Yellow'];
let newColors = [...colors, 'Purple', 'Blue', 'Indigo'];
console.log(newColors);

let numberValues = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
let newNumberValues = [...numberValues, 16, 17,18,19, 20];
console.log(numberValues);
console.log(newNumberValues);