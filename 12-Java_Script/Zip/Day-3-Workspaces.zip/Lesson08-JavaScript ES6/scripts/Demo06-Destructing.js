var arr = ["Hello", "World"];

var[ first, second ] = arr;

console.log(first + '\t' + second);

var colors = ['Red', 'Green', 'Blue', 'White', 'Black', 'Violet', 'Purple'];

var [color1, , color3, , color5] = colors;

console.log(color1 + '\t' + color3 + "\t" + color5);