function show(number1, number2=200) {
    console.log("Value of Num1 is : " + number1);
    console.log("Value of Num2 is : " + number2);
}

show(100);
show(300, 700);