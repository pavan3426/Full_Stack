// Simple Strings
let firstName = "Rahul";
let lastName = "Dravid";

console.log(firstName + "\t" + lastName);

// MultiLine Strings
let sentence: string = `Hello, \t $ _ Welcome to the Multiline \n Strings in TypeScript,
                        the typed SuperSet of JavaScript`;
console.log(sentence);
