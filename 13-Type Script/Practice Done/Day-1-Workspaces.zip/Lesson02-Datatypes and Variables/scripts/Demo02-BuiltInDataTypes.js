// Number Specific DataTypes
var ageLimit = 21;
var colorCode = 0x3434;
var octalCode = 156;
var binaryCode = 59;
// String Specific DataTypes
var empName = "Rahul";
var empDept = "Admin";
// Boolean Type
var isAMovie = true;
// Void Usage
function sayHello() {
    console.log("Hello Everyone ... ");
}
// Null Type and Undefined Type
var tempNumber = undefined;
tempNumber = null;
//tempNumber = 123;
// Any Type of Data 
var value1 = "Hello";
value1 = 234;
value1 = true;
// BigInt DataTypes
var big1 = BigInt(100); // BigInt Function
//let big2: bigint = 100n;
console.log(big1 + "\t");
