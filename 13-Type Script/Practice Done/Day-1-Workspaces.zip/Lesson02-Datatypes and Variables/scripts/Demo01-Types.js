var breakFast = "Masala Dosa", calories = 150, tasty = true;
function speak(food, energy) {
    console.log("Our " + food + " Has " + energy + " Calories");
}
speak(breakFast, calories);
