var breakFast: string = "Masala Dosa",
    calories: number = 150,
    tasty: boolean = true;


function speak(food: string, energy: number) {
    console.log("Our " + food + " Has " + energy + " Calories");
}

speak(breakFast, calories);