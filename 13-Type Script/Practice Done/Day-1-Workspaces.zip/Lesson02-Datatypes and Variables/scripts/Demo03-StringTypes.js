// Simple Strings
var firstName = "Rahul";
var lastName = "Dravid";
console.log(firstName + "\t" + lastName);
// MultiLine Strings
var sentence = "Hello, \t $ _ Welcome to the Multiline \n Strings in TypeScript,\n                        the typed SuperSet of JavaScript";
console.log(sentence);
