let welcomeMessage1 = "Welcome to the New Era of Developing Applications Using TypeScript";
console.log(welcomeMessage1);

//Create a New Heading Element 
let heading = document.createElement('h1');

heading.textContent = welcomeMessage1;

// Add the Header to the Document.
document.body.appendChild(heading);
