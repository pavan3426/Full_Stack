let welcomeMessage = "Welcome to the New Era of Developing Application Using TypeScript";
console.log(welcomeMessage);
