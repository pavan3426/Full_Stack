"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.sayHello = exports.welcomeMSG = void 0;
exports.welcomeMSG = "Welcome to the TypeScript Modules and Namespaces";
function sayHello() {
    return exports.welcomeMSG;
}
exports.sayHello = sayHello;
