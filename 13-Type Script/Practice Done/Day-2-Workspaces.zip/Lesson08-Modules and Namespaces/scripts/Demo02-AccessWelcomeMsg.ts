
console.log(welcomeMSG);