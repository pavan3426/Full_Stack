"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Demo03_Exporter_1 = require("./Demo03-Exporter");
var Demo03_Exporter_2 = require("./Demo03-Exporter");
console.log(Demo03_Exporter_1.welcomeMSG);
(0, Demo03_Exporter_2.sayHello)();
