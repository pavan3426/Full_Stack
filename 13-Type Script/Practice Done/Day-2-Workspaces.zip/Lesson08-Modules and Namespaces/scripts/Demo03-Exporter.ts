export var welcomeMSG = "Welcome to the TypeScript Modules and Namespaces";

export function sayHello() { 
    return welcomeMSG;
}
