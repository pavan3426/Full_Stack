import { Employee } from "./Demo05-Employee";

var empRef1 = new Employee(1001, "Rahul", 100000);
empRef1.displayDetails();

var empRef2 = new Employee(1002, "Smith", 100000);
empRef2.displayDetails();