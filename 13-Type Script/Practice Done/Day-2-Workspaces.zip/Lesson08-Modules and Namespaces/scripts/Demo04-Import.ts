import { welcomeMSG } from "./Demo03-Exporter";
import { sayHello } from "./Demo03-Exporter";

console.log(welcomeMSG);

sayHello();