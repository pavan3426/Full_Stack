var welcomeMSG = "Welcome to the Modules Concept in TypeScript";

function sayHello() {
    return welcomeMSG;
}

console.log(sayHello());