console.log(welcomeMSG);
