function add(a, b) {
    return a + b;
}
console.log(add("Hello"));
console.log(add(23));
