function show(num1: number, num2: number, num3: number = 200) {
    console.log(num1 + " " + num2 + " " + num3); 
}

show(100,500);