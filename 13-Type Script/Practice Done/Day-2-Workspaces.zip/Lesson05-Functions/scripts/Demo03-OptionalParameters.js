function greet(greeting, name) {
    return greeting + " " + name + " !";
}
console.log(greet("Hello"));
console.log(greet("Hi", "Rahul"));
