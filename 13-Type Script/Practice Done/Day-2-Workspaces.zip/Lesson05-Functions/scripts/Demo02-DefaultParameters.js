function show(num1, num2, num3) {
    if (num3 === void 0) { num3 = 200; }
    console.log(num1 + " " + num2 + " " + num3);
}
show(100, 500);
