package oe;

import javax.swing.JInternalFrame;

public class Frame1 extends JInternalFrame {
    public Frame1() {
        try {
            jbInit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void jbInit() throws Exception {
    }
}
