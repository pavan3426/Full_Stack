public class AverageNumber{

	public static void main(String args[]){
	
		int num1= 10;
		
		int num2= 20;
		
		int num3 = 45;
	
		int avg = (num1 +num2+ num3)/3;
	
		System.out.println("Number 1 = "+ num1);
		
		System.out.println("Number 2 = "+ num2);
		
		System.out.println("Number 3 = "+ num3);
		
		System.out.println("Average = "+ avg);
		
	
	
	
	
	}




}