package Week_Assignment;
	public class DummyClass {
		
		private String s1 = "private string";
		
		protected String s2 = "protected string";
		
		public String s3 = "public string";
		
		// Default is protected
		String s4 = "string without access modifier";
		
		
		private void method1(){
		}
		
		protected void method2(){
		}
		
		public void method3(){
		}
		// Default is protected.
		
		void method4(){
	}
}