public class OutputVariable{

	public static void main(String[] args){
	
	int value=10;
	
	char x;
	
	x='A';
	
	double grade = 11;
	
	System.out.println(value);
	
	System.out.println("The value of x = " + x);
	
	System.out.println("The value of grade = " + grade );
	
	
	}

}