import java.util.Map;

class SystemClass2 {
	
	public static void main(String args[]){
	
	Map m1 = System.getenv();

	System.out.println("System environment variables = " + m1);
	}
}