// Program to illustrate the demo of Primitive Datatypes Using the concept of OOPS.

public class PrimitiveDataTypes2
{
	// Declaration of Member Variables
      int i=7;
	  byte b=89;
	  short s=67;
      long l=56464;
      char c='M';
      float f=23.26f;
      double d=23.26;
      boolean bool=true;

	  public static void main(String args[])
	  {
	         PrimitiveDataTypes2 t = new PrimitiveDataTypes2();
	         System.out.println(t.i);
             System.out.println(t.b);
             System.out.println(t.s);
             System.out.println(t.l);
             System.out.println(t.c);
             System.out.println(t.f);
             System.out.println(t.d);
             System.out.println(t.bool);
        }
 }
