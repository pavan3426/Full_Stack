/* This Program is used for Concatenation of Strings */

public class ConcatString
{
	public static void main(String[] args)
    {
		int number = 10;
	    String age = "9";
        String s = "He is " + age + " years old.";
        String s1 = " The integer value is " +number+;
		System.out.println(s);
		System.out.println(s1);
     }
} 
