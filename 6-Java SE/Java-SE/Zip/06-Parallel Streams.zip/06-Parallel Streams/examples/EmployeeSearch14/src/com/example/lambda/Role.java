package com.example.lambda;

/**
 * 
 */
public enum Role { STAFF, MANAGER, EXECUTIVE }
