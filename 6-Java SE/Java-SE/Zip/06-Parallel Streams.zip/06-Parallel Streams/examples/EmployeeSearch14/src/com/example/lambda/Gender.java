package com.example.lambda;

/**
 * 
 */
public enum Gender { MALE, FEMALE }
