package com.example.lambda;

/**
 *
 * @author MikeW
 */
public class Main {

  public static void main(String[] args) {
    
      LazyTest.main(args);
      
  }
}
