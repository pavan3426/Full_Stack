package com.example.lambda;

/**
 *
 * @author MikeW
 */
public class Main {

  public static void main(String[] args) {
    
    RoboMailTest01.main(args);
    
  }
}
