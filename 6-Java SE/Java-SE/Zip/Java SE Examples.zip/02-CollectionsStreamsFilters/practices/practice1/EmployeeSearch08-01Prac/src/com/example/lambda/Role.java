package com.example.lambda;

/**
 * @author MikeW
 */
public enum Role { STAFF, MANAGER, EXECUTIVE }
