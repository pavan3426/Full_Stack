package java.util.function;

public interface Consumer<T> {
    
    public void Accept(T t);
    
}
