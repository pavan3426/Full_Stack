package com.example.lambda;

/**
 *
 * @author oracle
 */
public class Main {
  public static void main(String[] args) {
    
  }
}
