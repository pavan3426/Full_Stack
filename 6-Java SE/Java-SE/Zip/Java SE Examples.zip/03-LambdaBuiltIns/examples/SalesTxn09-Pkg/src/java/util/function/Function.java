package java.util.function;

public interface Function<T,R> {

    public R apply(T t);
}
