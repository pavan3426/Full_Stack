package java.util.function;

public interface Supplier<T> {
    
    public T get();
}
