package com.example;

public class AnalyzerTool {
  public boolean arrContains(String sourceStr, String searchStr){
    return sourceStr.contains(searchStr);
  }  
}
