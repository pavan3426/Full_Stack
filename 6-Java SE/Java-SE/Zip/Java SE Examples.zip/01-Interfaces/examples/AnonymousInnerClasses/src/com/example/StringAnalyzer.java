package com.example;

public interface StringAnalyzer {
  public boolean analyze(String sourceStr, String searchStr);
}
