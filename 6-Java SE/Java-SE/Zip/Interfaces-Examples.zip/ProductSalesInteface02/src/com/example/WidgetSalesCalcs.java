package com.example;

public interface WidgetSalesCalcs extends SalesCalcs{
  public String getWidgetType();
}
