package com.example;

public interface SalesCalcs {
  public String getName();
  public double calcSalesPrice();
  public double calcCost();
  public double calcProfit();
}
